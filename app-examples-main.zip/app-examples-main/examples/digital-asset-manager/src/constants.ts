export const filteredCategories = [
  "Trust center documentation",
  "Video Assets",
  "Fonts",
];

export const learnMoreLink =
  "https://miro.atlassian.net/wiki/spaces/~651066296/pages/2579824793/Asset+Catalog";
