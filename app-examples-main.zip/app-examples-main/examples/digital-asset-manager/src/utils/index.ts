export const toTitleCase = (title: string) => {
  return title.charAt(0).toUpperCase() + title.slice(1);
};
