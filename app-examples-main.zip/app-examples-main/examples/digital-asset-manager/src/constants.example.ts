export const filteredCategories = [];

export const learnMoreLink = "";
